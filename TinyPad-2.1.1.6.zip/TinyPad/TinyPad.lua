local tinypad = TinyPad
local editBox = TinyPadEditBox

local current = 1 -- текущая просматриваемая страница

local WoTLK = select(4,GetBuildInfo())>=30000

TinyPadPages = {} -- страницы для TinyPad находятся в таблице строк с числовым индексом (или таблицах для страниц с закладками)
TinyPadSettings = {} -- настройки (заблокировано, шрифт)
local pages, settings -- назначит их в PLAYER_LOGIN после загрузки savevars


-- список шрифтов для циклического просмотра
tinypad.fonts = {
	{"Fonts\\FRIZQT__.TTF",10},
	{"Fonts\\FRIZQT__.TTF",12}, -- умолчание 
	{"Fonts\\FRIZQT__.TTF",16},
	{"Fonts\\ARIALN.TTF",12},
	{"Fonts\\ARIALN.TTF",16},
	{"Fonts\\ARIALN.TTF",20},
	{"Fonts\\MORPHEUS.ttf",16,"OUTLINE"},
	{"Fonts\\MORPHEUS.ttf",24,"OUTLINE"},
	-- добавь сюда шрифты
}

function tinypad:PLAYER_LOGIN()
	-- сохраненные вары
	pages = TinyPadPages
	settings = TinyPadSettings
	settings.Font = settings.Font or 2
	-- константы интерфейса привязки клавиш
	BINDING_HEADER_TINYPAD = "TinyPad"
	BINDING_NAME_TINYPAD_TOGGLE = "Show/Hide TinyPad"
	BINDING_NAME_TINYPAD_SEARCH = "Search within TinyPad"
	-- слэш-команда
	SlashCmdList["TINYPADSLASH"] = tinypad.SlashHandler
	SLASH_TINYPADSLASH1 = "/pad"
	SLASH_TINYPADSLASH2 = "/tinypad"
	SLASH_TINYPADSLASH3 = "/tp"
	-- настроить остальные
	-- editBox:SetHyperlinksEnabled(true)
	self:SetMinResize(268,96)
	tinypad:UpdateLock()
	tinypad:UpdateFont()

	-- прикрепить всплывающую подсказку и OnClicks к каждой строке заголовка/кнопке поиска
	for key,info in pairs({
		["close"] = {"Закрыть","Версия: "..GetAddOnMetadata("TinyPad","Version"),tinypad.Toggle},
		["new"] = {"Новая страница","Добавить новую страницу после последней страницы.\n\n\124cFFA5A5A5Удерживайте Shift, чтобы вставить после текущей страницы.",tinypad.NewPage},
		["delete"] = {"Удалить","Удалить эту страницу навсегда.\n\n\124cFFA5A5A5Hold Shift для удаления без подтверждения.",tinypad.DeletePage },
		["run"] = {"Запуск скрипта","Запустите эту страницу как lua-скрипт.",tinypad.RunPage},
		["undo"] = {"Отмена","Вернуть эту страницу к последнему сохраненному тексту.",tinypad.Undo},
		["cminimap"] = {"Кнопка у Миникарты","Включить или выключить отображение кнопки у миникарты.",MytinyicoButton.Toggle},
		["config"] = {"Опции","Поиск на страницах текста, изменение шрифта или блокировка окна.",tinypad.TogglePanel},
		["bookmark"] = {"Закладки","Переход на страницу с закладками или управление закладками.",tinypad.ToggleBookmarks},
		["first"] = {"Первая страница","Перейти на первую страницу\n\n\124cFFA5A5A5Удерживайте Shift, чтобы переместить эту страницу на первую страницу.",tinypad.FirstPage},
		["previous"] = {"Предыдущая","Перейти на предыдущую страницу.\n\n\124cFFA5A5A5Удерживайте Shift, чтобы переместить эту страницу на одну страницу назад.",tinypad.PreviousPage},
		["next"] = {"Следующая","Перейти на следующую страницу.\n\n\124cFFA5A5A5Удерживайте Shift, чтобы переместить эту страницу вперед на одну страницу.",tinypad.NextPage},
		["last"] = {"Последняя страница","Перейти на последнюю страницу.\n\n\124cFFA5A5A5Удерживайте Shift, чтобы переместить эту страницу на последнюю страницу.",tinypad.LastPage},
		["panel.find"] = {"Найти следующее","Найти следующую страницу с этим текстом.\n\n\124cFFA5A5A5Удерживайте Shift, чтобы найти последнюю страницу с этим текстом.",tinypad.SearchOnEnter},
		["panel.lock"] = {"Блок окна","Заблокируйте или разблокируйте окно, чтобы предотвратить его перемещение или закрытие с помощью клавиши ESCape.",tinypad.ToggleLock},
		["panel.font"] = {"Шрифт","Циклический просмотр различных шрифтов.\n\n\124cFFA5A5A5Удерживайте Shift, чтобы вернуться назад.",tinypad.NextFont},
		["bookmarks.add"] = {"Сохранить закладку","Добавить эту страницу в закладки. Когда страница добавлена ​​в закладки, вы можете вернуться к ней позже, выбрав ее в меню ниже."},
		["bookmarks.remove"] = {"Удалить закладку","Удалить закладку для этой страницы."},
	}) do
		local parentKey,subKey = key:match("(%w+)%.(%w+)")
		local button = parentKey and tinypad[parentKey][subKey] or tinypad[key]
		button.tooltipTitle = info[1]
		button.tooltipBody = info[2]
		if info[3] then
			button:SetScript("OnClick",info[3])
		end
	end

	-- если страницы еще не созданы, создайте их
	if #pages==0 then
		tinsert(pages,"")
	end
	current = #pages

	self:RegisterEvent("PLAYER_LOGOUT")

	-- настроить перехваты ссылок в чате
	tinypad:RegisterEvent("ADDON_LOADED") -- Крючки торговых навыков и достижений должны ждать битов LoD
	local old_ChatEdit_InsertLink = ChatEdit_InsertLink
	function ChatEdit_InsertLink(text)
		if editBox:HasFocus() then
			editBox:Insert(text)
			return true -- предотвращает отображение кадра разделения стека
		else
			return old_ChatEdit_InsertLink(text)
		end
	end

end

function tinypad:PLAYER_LOGOUT()
	if tinypad:IsVisible() then
		tinypad:SaveCurrentPage()
	end
end

-- чтобы вставить ссылки на ремесла и достижения, их хуки должны дождаться загрузки этих битов LoD
function tinypad:ADDON_LOADED(addon)
	if addon=="Blizzard_TradeSkillUI" then
		local linkButton = WoTLK and TradeSkillFrame.LinkToButton or TradeSkillLinkButton
		local old = linkButton:GetScript("OnClick")
		linkButton:SetScript("OnClick",function(self,...)
			if editBox:HasFocus() then
				return editBox:Insert(WoTLK and C_TradeSkillUI.GetTradeSkillListLink() or GetTradeSkillListLink())
			else
				return oldTradeSkillLink(self,...)
			end
		end)
	elseif addon=="Blizzard_AchievementUI" then
		local old_AchievementButton_OnClick = AchievementButton_OnClick
		function AchievementButton_OnClick(self,...)
			if editBox:HasFocus() and IsModifiedClick("CHATLINK") then
				return editBox:Insert(GetAchievementLink(self.id))
			else
				return old_AchievementButton_OnClick(self,...)
			end
		end
	end
end

-- возвращает тело заданного номера страницы
function tinypad:GetPageText(page)
	local page = page or current
	if type(pages[page])=="table" then -- добавлен в закладки
		return pages[page][2]
	else
		return pages[page] -- не добавлен в закладки
	end
end

function tinypad:Toggle()
  if tinypad:IsVisible() then
    tinypad:Hide()
  else
    tinypad:Show()
  end
end

function tinypad:OnMouseDown()
	if not settings.Lock then
		tinypad:StartMoving()
	end
end

function tinypad:OnMouseUp()
	if not settings.Lock then
		tinypad:StopMovingOrSizing()
	end
end

function tinypad:OnShow()
	self:UpdateESCable()
	self:ShowPage(current)
end

function tinypad:OnHide()
	tinypad:SaveCurrentPage()
	tinypad.panel:Hide()
	self:UpdateESCable()
end

function tinypad:OnTextChanged()
  if tinypad:GetPageText()~=editBox:GetText() then
    tinypad.undo:Enable()
  else
    tinypad.undo:Disable()
  end
end

-- это имитирует ScrollingEdit_OnCursorChanged в UIPanelTemplates.lua, но вместо этого
-- наличие постоянно работающего OnUpdate, это просто включает OnUpdate для одного кадра
function tinypad:OnCursorChanged(x,y,w,h)
	self.cursorOffset = y
	self.cursorHeight = h
	self.handleCursorChange = true;
	self:SetScript("OnUpdate",tinypad.OnCursorOnUpdate)
end

-- это срабатывает от OnCursorChanged и немедленно выключается и вызывает
-- ScrollingEdit_OnUpdate определено в UIPanelTemplates.lua
function tinypad:OnCursorOnUpdate(elapsed)
	self:SetScript("OnUpdate",nil)
	ScrollingEdit_OnUpdate(self,elapsed,self:GetParent())
end

-- когда пользователь нажимает на ссылку в главном поле редактирования, большая часть данных переходит в SetItemRef
-- ремесла и способности питомцев требуют дополнительной обработки, чтобы заставить их переключаться
-- также, если ремесло поднято, щелчок по ссылке должен перейти к этому предмету во фрейме ремесла.
function tinypad:OnHyperlinkClick(link,text,button)
	if IsModifiedClick("CHATLINK") and not editBox:HasFocus() then
		SetItemRef(link,text,button) -- если сдвиг вниз, отправить прямо в SetItemRef
	else
		if link:match("^trade:") and TradeSkillFrame and TradeSkillFrame:IsVisible() then
			if text==GetTradeSkillListLink() then
				HideUIPanel(TradeSkillFrame) -- нажали на профессию, на которую мы смотрим, скрыть ее
			else
				SetItemRef(link,text,button) -- выбрал другой навык, отправьте его
			end
		elseif link:match("^battlePetAbil:") and FloatingPetBattleAbilityTooltip:IsVisible() then
			FloatingPetBattleAbilityTooltip:Hide()
		else -- ничего из вышеперечисленного, пусть это идет в SetItemRef
			if TradeSkillFrame and TradeSkillFrame:IsVisible() then -- если профессиональные навыки повышаются, посмотрите, есть ли к чему перейти
				local itemName = GetItemInfo(link)
				local numRecipes = GetNumTradeSkills()
				for i=1,numRecipes do
					local tradeLink = GetTradeSkillItemLink(i)
					if tradeLink and GetItemInfo(tradeLink)==itemName then
						TradeSkillFrame_SetSelection(i) -- нажатая ссылка находится в открытом торговом навыке, выберите ее
						local range=TradeSkillListScrollFrame:GetVerticalScrollRange() -- и прокрутите до него
						TradeSkillListScrollFrame:SetVerticalScroll(min(range,max(0,range*(i+(i/numRecipes-0.5)*8)/numRecipes)))
						return
					end
				end
			end
			SetItemRef(link,text,button)
		end
	end
end

-- максимум одна запись из TinyPad должна быть в UISpecialFrames и только тогда, когда она видна:
-- TinyPadЗакладки > TinyPad
-- это пройдет через UISpecialFrames и гарантирует, что только самый верхний кадр находится в таблице, и удалит другие
function tinypad:UpdateESCable()
	local specialFound
	local specialFrame = (tinypad.bookmarks:IsVisible() and "TinyPadBookmarks") or (not settings.Lock and tinypad:IsVisible() and "TinyPad")
	for i=#UISpecialFrames,1,-1 do
		local frameName = UISpecialFrames[i]
		if frameName=="TinyPad" or frameName=="TinyPadBookmarks" then
			if frameName~=specialFrame then
				tremove(UISpecialFrames,i)
			else
				specialFound = true
			end
		end
	end
	if not specialFound and specialFrame then
		tinsert(UISpecialFrames,specialFrame)
	end
end

-- когда окно заблокировано, рамка черная, при разблокировке серая
function tinypad:UpdateLock()
	local c = settings.Lock and 0 or .75
	tinypad:SetBackdropBorderColor(c,c,c)
	tinypad.panel:SetBackdropBorderColor(c,c,c)
  if settings.Lock then
    tinypad.resize:Hide()
  else
    tinypad.resize:Show()
  end
end

function tinypad:UpdateFont()
	editBox:SetFont(unpack(tinypad.fonts[settings.Font]))
end

--[[ кнопки заголовка ]]

function tinypad:UpdateButtonStates()
  if current>1 then
    tinypad.first:Enable()
    tinypad.previous:Enable()
  else
  	tinypad.first:Disable()
  	tinypad.previous:Disable()
  end

  if current<#pages then
    tinypad.next:Enable()
    tinypad.last:Enable()
  else
  	tinypad.next:Disable()
  	tinypad.last:Disable()
  end

  if editBox:GetText()~=pages[current] then
   tinypad.undo:Enable()
  else
	 tinypad.undo:Disable()
  end
end

function tinypad:SaveCurrentPage()
	if type(pages[current])=="table" then
		pages[current][2] = editBox:GetText()
	else
		pages[current] = editBox:GetText()
	end
end

function tinypad:ShowPage(page)
	if not tinypad:IsVisible() then
		tinypad:Show()
	end
	if page and page>0 and page<=#pages then
		current = page
		editBox:ClearFocus()
		editBox:SetText(tinypad:GetPageText())
		editBox:SetCursorPosition(0)
		tinypad.pageNumber:SetText(current)
		tinypad:UpdateButtonStates()
		tinypad.bookmarks:Hide()
	end
end

function tinypad:NewPage()
	tinypad:SaveCurrentPage()
	if IsShiftKeyDown() then
		tinsert(pages,current+1,"")
		tinypad:ShowPage(current+1)
	else
		tinsert(pages,"")
		tinypad:ShowPage(#pages)
	end
end

function tinypad:NextPage()
	tinypad:SaveCurrentPage()
	if IsShiftKeyDown() then
		tinypad:SwapPages(current,current+1)
	end
	current = min(#pages,current+1)
	tinypad:ShowPage(current)
end

function tinypad:PreviousPage()
	tinypad:SaveCurrentPage()
	if IsShiftKeyDown() then
		tinypad:SwapPages(current,current-1)
	end
	current = max(1,current-1)
	tinypad:ShowPage(current)
end

function tinypad:FirstPage()
	tinypad:SaveCurrentPage()
	if IsShiftKeyDown() then
		tinypad:MovePage(current,1)
	end
	current = 1
	tinypad:ShowPage(current)
end

function tinypad:LastPage()
	tinypad:SaveCurrentPage()
	if IsShiftKeyDown() then
		tinypad:MovePage(current,#pages)
	end
	current = #pages
	tinypad:ShowPage(current)
end

function tinypad:DeletePage(bypass)
	if IsShiftKeyDown() or bypass==true or editBox:GetText():len()==0 then
		tremove(pages,current)
		if #pages==0 then
			tinsert(pages,"")
		end
		tinypad:ShowPage(min(#pages,current))
	else
		StaticPopupDialogs["TINYPADCONFIRM"] = StaticPopupDialogs["TINYPADCONFIRM"] or { text="Удалить эту страницу?", button1=YES, button2=NO, timeout=0, whileDead=1, OnAccept=function() tinypad:DeletePage(true) end}
		StaticPopup_Show("TINYPADCONFIRM")
	end
end

function tinypad:RunPage(page)
	tinypad:SaveCurrentPage()
	RunScript(tinypad:GetPageText(tonumber(page)):gsub("^/run",""))
end

function tinypad:Undo()
	local position = editBox:GetCursorPosition()
	editBox:SetText(tinypad:GetPageText())
	editBox:SetCursorPosition(position)
end

--[[ движущиеся страницы ]]

-- меняет местами номер страницы page1 с номером страницы page2
function tinypad:SwapPages(page1,page2)
	if pages[page1] and pages[page2] then
		local save = pages[page1]
		pages[page1] = pages[page2]
		pages[page2] = save
	end
end

-- перемещает номер страницы с на номер страницы на
function tinypad:MovePage(from,to)
	if from<1 or from>#pages or to<1 or to>#pages then
		return -- не позволять странице выходить за пределы диапазона страниц
	end
	local save = pages[from]
	tremove(pages,from)
	tinsert(pages,to,save)
end

--[[ панель ]]

function tinypad:TogglePanel()
	tinypad.bookmarks:Hide()
  if tinypad.panel:IsShown() then
    tinypad.panel:Hide()
  else
    tinypad.panel:Show()
  end
	if not tinypad:IsVisible() then
		tinypad:Show()
	end
	if tinypad.panel:IsShown() then
		tinypad.panel.searchBox:SetFocus()
	end
end

function tinypad:ToggleLock()
	settings.Lock = not settings.Lock
	tinypad:UpdateESCable()
	tinypad:UpdateLock()
end

function tinypad:NextFont()
	local numFonts = #tinypad.fonts
	settings.Font = (settings.Font+(IsShiftKeyDown() and (numFonts-2) or 0))%numFonts + 1
	tinypad:UpdateFont()
end

--[[ поиск ]]

local function literal(c) return "%"..c end
local function caseinsensitive(c) return format("[%s%s]",c:lower(),c:upper()) end

function tinypad:SearchOnTextChanged()
	if tinypad.undo:IsEnabled() then
		tinypad:SaveCurrentPage()
		tinypad.undo:Disable()
	end
	tinypad.searchText = self:GetText():gsub("[%(%)%.%%%+%-%*%?%[%]%^%$]",literal):gsub("%a",caseinsensitive)
	if tinypad.searchText:len()>0 then
		tinypad:UpdateSearchCount()
		tinypad.panel.searchBox.clear:Show()
		tinypad.panel.find:Enable()
	else
		tinypad.panel.result:SetText("Поиск:")
		tinypad.panel.searchBox.clear:Hide()
		tinypad.panel.find:Disable()
	end
end

function tinypad:UpdateSearchCount()
	local search = tinypad.searchText
	local count = 0
	for i=1,#pages do
		if tinypad:GetPageText(i):match(search) then
			count = count + 1
		end
	end
	tinypad.panel.result:SetText(format("%s\nНайдено",count==0 and "Не" or count))
end

function tinypad:SearchOnEnter()
	local search = tinypad.searchText
	if search and search:len()>0 then
		if tinypad.undo:IsEnabled() then
			tinypad:SaveCurrentPage()
			tinypad.undo:Disable()
			tinypad:UpdateSearchCount()
		end
		local page = current
		local numPages = #pages
		local direction = IsShiftKeyDown() and -2 or 0
		for i=1,numPages do
			page = (page+direction)%numPages+1
			if tinypad:GetPageText(page):match(search) then
				tinypad:ShowPage(page)
				return
			end
		end
	end
end

--[[ закладки ]]

function tinypad:ToggleBookmarks()
	tinypad.panel:Hide()
	if tinypad.bookmarks:IsVisible() then
		tinypad.bookmarks:Hide()
	else
		tinypad:UpdateBookmarks()
		tinypad.bookmarks:SetFrameLevel(tinypad:GetFrameLevel()+5)
		tinypad.bookmarks:Show()
	end
end

-- через секунду после того, как мышь не находится над кнопкой закладки или рамкой закладок, рамка закладки скрывается
function tinypad:BookmarksOnUpdate(elapsed)
	if MouseIsOver(self) or MouseIsOver(tinypad.bookmark) or tinypad.bookmarks.prompt:HasFocus() then
		self.timer = 0
	else
		self.timer = self.timer + elapsed
		if self.timer > 1 then
			self:Hide()
		end
	end
end

-- возвращает доступную кнопку закладки из пула
function tinypad:GetBookmarkButton()
	for _,button in ipairs(tinypad.bookmarks.buttons) do
		if not button:IsShown() then
			return button
		end
	end
	local button = CreateFrame("Button",nil,tinypad.bookmarks,"TinyPadBookmarkTemplate")
	tinsert(tinypad.bookmarks.buttons,button)
	return button
end

-- обновляет окно закладок для отображения всех страниц с закладками
function tinypad:UpdateBookmarks()
	local bookmarks = tinypad.bookmarks
	bookmarks.buttons = bookmarks.buttons or {}
	bookmarks.prompt:Hide()
  if type(pages[current])=="table" then
    bookmarks.add:Hide()
    bookmarks.remove:Show()
  else
  	bookmarks.add:Show()
  	bookmarks.remove:Hide()
  end
	for i=1,#bookmarks.buttons do
		bookmarks.buttons[i]:Hide()
	end
	local yoffset = -10
	local showBack = true
	for i=1,#pages do
		if type(pages[i])=="table" then
			local button = tinypad:GetBookmarkButton()
			button:SetID(i)
			yoffset = yoffset - 18
			button:SetPoint("TOP",0,yoffset)
			button.name:SetText(pages[i][1])
      if showBack then
        button.back:Show()
      else
        button.back:Hide()
      end
			showBack = not showBack -- чередовать, отображается ли задняя часть или нет (более светлый фон)
      if i==current then
        button.mark:Show()
      else
        button.mark:Hide()
      end
			button.name:SetWidth(i==current and 132 or 140) -- и отрегулируйте ширину для отметки
			button:Show()
		end
	end
	bookmarks:SetHeight(-yoffset+24)
end

function tinypad:BookmarkOnClick()
	if self:GetID()>0 then
		tinypad:ShowPage(self:GetID())
		if IsShiftKeyDown() then
			tinypad:RunPage()
		end
	end
end

function tinypad:BookmarkPromptOnTextChanged()
	local text = self:GetText()
	if text:len()==0 then
		self.enter:Disable()
		self.label:Show()
	else
		self.enter:Enable()
		self.label:Hide()
	end
end

function tinypad:BookmarkPromptOnEnter()
	local title = self:GetText()
	if title:len()>0 then
		pages[current] = { title, pages[current] }
	end
	tinypad:UpdateBookmarks()
end

function tinypad:BookmarkRemove()
	local text = self:GetPageText()
	pages[current] = text
	tinypad:UpdateBookmarks()
end

--[[ tooltips ]]

function tinypad:ShowTooltip()
	if self.tooltipTitle then
		GameTooltip_SetDefaultAnchor(GameTooltip,UIParent)
		GameTooltip:AddLine(self.tooltipTitle)
		if self.tooltipBody then
			GameTooltip:AddLine(self.tooltipBody,.95,.95,.95,true)
		end
		GameTooltip:Show()
	end
end

function tinypad:ShowBookmarkTooltip()
	local page = self:GetID()
	GameTooltip_SetDefaultAnchor(GameTooltip,UIParent)
	GameTooltip:AddLine(pages[page][1],1,.82,0,1)
	GameTooltip:AddLine(format("Страница %d",page),.65,.65,.65)
	GameTooltip:AddLine(pages[page][2]:sub(1,128):gsub("\n"," "),.9,.9,.9,1)
	GameTooltip:AddLine("Удерживайте Shift, чтобы запустить эту страницу как скрипт.",.65,.65,.65,1)
	GameTooltip:Show()
end

--[[ обработчик косой черты ]]

-- /pad # перейдет на страницу, /pad run # запустит страницу, только /pad переключает окно
function tinypad.SlashHandler(msg)
	msg = (msg or ""):lower()
	local runPage = tonumber(msg:match("run (%d+)"))
	local page = tonumber(msg:match("(%d+)"))
	if msg=="run" then -- запустить в одиночку запустит текущую страницу
		tinypad:RunPage()
	elseif runPage and pages[runPage] then -- run <num> запустит страницу <num>
		tinypad:RunPage(runPage)
	elseif page and pages[page] then -- Только <num> перейдет на страницу <num>
		tinypad:ShowPage(page)
	else
		tinypad:Toggle()
	end
end

--[[ функции для внешнего использования ]]

-- TinyPad:Run(<число>) запустит страницу <число>
function tinypad:Run(page)
	if type(self)=="number" then -- Вместо TinyPad:Run использовался TinyPad.Run.
		page = self
	end
	if type(page)=="number" then
		tinypad:RunPage(page)
	end
end

-- это удалит все страницы, содержащие регулярное выражение (например, "^Glyphioneer Suggestions"
-- удалит все страницы, которые начинаются (^) с «Предложения Glyphioneer». Этот
-- используется в основном для аддонов, которые генерируют отчет и хотят очистить
-- старые копии данных. Используйте осторожно!
function tinypad:DeletePagesContaining(regex)
	if type(self)=="string" then -- TinyPad.Delete... was used instead of TinyPad:Delete...
		regex = self
	end
	if type(regex)=="string" then
		for i=#pages,1,-1 do
			if tinypad:GetPageText(i):match(regex) then
				tremove(pages,i)
			end
		end
		if #pages==0 then
			tinsert(pages,"")
		end
		current = min(current,#pages)
		tinypad:ShowPage(current)
	end
end

-- TinyPad:Insert("body") -- создает новую страницу с "текстом"
-- TinyPad:Insert("body","title") -- создает новую страницу с закладкой "title", содержащую "text"
-- TinyPad:Insert("body",<number>) -- создает новую страницу с "текстом" на странице <number>
-- TinyPad:Insert("body",<number>,"title") -- создает новую страницу с закладкой "title", которая содержит "text" на странице <number>
function tinypad:Insert(body,page,bookmark)
	if type(self)=="string" then -- Вместо TinyPad:Insert использовался TinyPad.Insert.
		bookmark = page
		page = body
		body = self
	end
	if not type(body)=="string" then
		return -- действительное тело не дано, оставить
	end
	if not page then -- ("тело")
		tinsert(pages,body)
		current = #pages
	elseif type(page)=="string" then -- ("тело","заглавие")
		tinsert(pages,{page,body})
		current = #pages
	else -- страница это номер
		page = max(1,min(#pages+1,page)) -- убедитесь, что он находится в пределах досягаемости
		if not bookmark then
			tinsert(pages,page,body) -- ("тело",<количество>)
		else
			tinsert(pages,page,{bookmark,body}) -- ("тело",<количество>,"заглавие")
		end
		current = page
	end
	tinypad:ShowPage(current)
end

-- [[ Кнопка ]] --
-- Создание кнопки на миникарте
local tinyico = CreateFrame("Button", "MytinyicoButton", Minimap)
-- Подсвечиваем кнопку на наведении
tinyico:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");
-- Стандартный размер кнопки
tinyico:SetWidth(31)
tinyico:SetHeight(31)
tinyico:SetFrameStrata("LOW")
-- Мы сделаем нашу кнопку перетягиваемой
tinyico:SetMovable(true)
tinyico:RegisterForDrag("LeftButton")
tinyico:RegisterForClicks("AnyUp");
-- Задаем начальную позицию кнопки
tinyico:SetPoint("CENTER", -12, -80)

-- Главная иконка кнопки
tinyico.icon = tinyico:CreateTexture(nil, "BACKGROUND")
tinyico.icon:SetTexture("Interface\\AddOns\\TinyPad\\Buttons")
tinyico.icon:SetTexCoord(0.125,0.25,0.5,0.625)
tinyico.icon:SetWidth(23);
tinyico.icon:SetHeight(23);
tinyico.icon:SetPoint("CENTER", 0, 0)

-- Рамка кнопки
tinyico.border = tinyico:CreateTexture(nil, "BORDER")
tinyico.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
-- Текстура в ресурсах подана не центрированная, подкорректируем её
tinyico.border:SetTexCoord(0,0.6,0,0.6);
tinyico.border:SetAllPoints(tinyico);

-- Вспомогательный масив всех видов формы миникарты, используется для расчета позиции кнопки при перетаскивании
local minimapShapes = {
	["ROUND"] = {true, true, true, true},
	["SQUARE"] = {false, false, false, false},
	["CORNER-TOPLEFT"] = {true, false, false, false},
	["CORNER-TOPRIGHT"] = {false, false, true, false},
	["CORNER-BOTTOMLEFT"] = {false, true, false, false},
	["CORNER-BOTTOMRIGHT"] = {false, false, false, true},
	["SIDE-LEFT"] = {true, true, false, false},
	["SIDE-RIGHT"] = {false, false, true, true},
	["SIDE-TOP"] = {true, false, true, false},
	["SIDE-BOTTOM"] = {false, true, false, true},
	["TRICORNER-TOPLEFT"] = {true, true, true, false},
	["TRICORNER-TOPRIGHT"] = {true, false, true, true},
	["TRICORNER-BOTTOMLEFT"] = {true, true, false, true},
	["TRICORNER-BOTTOMRIGHT"] = {false, true, true, true},
}

-- Функция обновления кнопки. Подключается при начале перетаскивания, отключается по окончанию.
local function onupdate(self)
	if self.isMoving then
		-- Расчитываем угол позиции кнопки относительно центра миникарты
		local mx, my = Minimap:GetCenter()
		local px, py = GetCursorPosition()
		local scale = Minimap:GetEffectiveScale()
		px, py = px / scale, py / scale
	
		local angle = math.rad(math.deg(math.atan2(py - my, px - mx)) % 360)
		
		local x, y, q = math.cos(angle), math.sin(angle), 1
		if x < 0 then q = q + 1 end
		if y > 0 then q = q + 2 end
		-- В зависимости от формы миникарты позиционирование изменяется
		local minimapShape = GetMinimapShape and GetMinimapShape() or "ROUND"
		local quadTable = minimapShapes[minimapShape]
		if quadTable[q] then
			x, y = x*80, y*80
		else
			local diagRadius = 103.13708498985 --math.sqrt(2*(80)^2)-10
			x = math.max(-80, math.min(x*diagRadius, 80));
			y = math.max(-80, math.min(y*diagRadius, 80));
		end
		self:ClearAllPoints();
		self:SetPoint("CENTER", Minimap, "CENTER", x, y);
	end
end
-- Смещаем иконку на 1 пиксель при нажатии на кнопку
tinyico:SetScript("OnMouseDown", function(self, button)
	self.icon:SetPoint("CENTER", 1, -1);
end);
-- Возвращаем изначальную позицию иконки
tinyico:SetScript("OnMouseUp", function(self, button)
	self.icon:SetPoint("CENTER", 0, 0);
end);
-- Начинаем перетаскивание кнопки
tinyico:SetScript("OnDragStart",
	function(self)
		if IsShiftKeyDown() then
			self.isMoving = true
			self:SetScript("OnUpdate", function(self) onupdate(self) end)
		end
	end)
-- Заканчиваем перетаскивание и сообщаем системе новую позицию кнопки, для автоматического сохранения.
tinyico:SetScript("OnDragStop",
	function(self)
		self.isMoving = nil
		self:SetScript("OnUpdate", nil)
		self:SetUserPlaced(true)
	end)
-- Покажем собственную подсказку
tinyico:SetScript("OnEnter",
	function(self)
		GameTooltip:SetOwner(self, "ANCHOR_LEFT")
		-- Задаем текст подсказки
		GameTooltip:AddLine("TinyPad")
		GameTooltip:Show()
end)
-- Прячем нашу подсказку
tinyico:SetScript("OnLeave", function(self)
		GameTooltip:Hide();
		self.icon:SetPoint("CENTER", 0, 0);
end)
-- Здесь можно обрабатывать события нажатия
tinyico:SetScript("OnClick", TinyPad.Toggle)
-- Отображение или скрытие кнопки у миникарты
function MytinyicoButton:Toggle(self, tinyico)
	if MytinyicoButton:IsVisible() then
		MytinyicoButton:Hide()
	else
		MytinyicoButton:Show()
	end
end

print ("TinyPad - это простой, но мощный аддон блокнота, который прост в использовании. Для вызова окна можно воспользоваться командой /tp или кнопкой у миникарты. (Перемещение кнопки у миникарты: Shift+ЛКМ). Версия: "..GetAddOnMetadata("TinyPad","Version"))